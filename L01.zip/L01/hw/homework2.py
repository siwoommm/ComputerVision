import cv2
import numpy as np
import sys

# 웹캠 영상 로드
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        print('프레임 획득에 실패하여 루프를 나갑니다.')
        break

    # 그레이스케일 변환 및 에지 검출
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 100, 200)

    # 원본 영상과 에지 검출 영상 가로로 연결하여 화면에 출력력
    stacked = cv2.hconcat([frame, cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)])
    cv2.imshow('Edge Detection', stacked)

    # 'q' 키를 누르면 영상 창 종료
    key=cv2.waitKey(1)
    if key == ord('q'): 
        break

cap.release()
cv2.destroyAllWindows()
