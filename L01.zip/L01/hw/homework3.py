import cv2
import numpy as np
import sys

# 이미지 불러오고 화면에 출력
img = cv2.imread('paint.jpg')
if img is None:
    sys.exit('파일을 찾을 수 없습니다.')

clone = img.copy()
roi = None
drawing = False
ix, iy = -1, -1

# 사각형 그리며 영역 선택 
def draw(event, x, y, flags, param):
    global ix, iy, drawing, roi, img

    if event == cv2.EVENT_LBUTTONDOWN:  # 마우스 클릭 시작
        drawing = True
        ix, iy = x, y
    elif event == cv2.EVENT_MOUSEMOVE and drawing:  # 드래그 중
        img = clone.copy()
        cv2.rectangle(img, (ix, iy), (x, y), (0, 255, 0), 2)
    elif event == cv2.EVENT_LBUTTONUP:  # 마우스 버튼을 놓을 때 해당 ROI 영역 별도 창에 출력
        drawing = False
        x1, y1 = min(ix, x), min(iy, y)  
        x2, y2 = max(ix, x), max(iy, y)  

        roi = clone[y1:y2, x1:x2]  # numpy 슬라이싱으로 ROI 추출

        if roi.size > 0: 
            cv2.namedWindow('ROI')
            cv2.imshow('ROI', roi) 


cv2.namedWindow('Drawing')
cv2.setMouseCallback('Drawing', draw)   # 마우스 이벤트 처리리

while True:
    cv2.imshow('Drawing', img)

    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'): 
        break
    elif key == ord('r'):  # 영역 선택 리셋
        img = clone.copy()
        roi = None
    elif key == ord('s') and roi is not None:  # ROI 저장
        cv2.imwrite('roi.jpg', roi)
        print("ROI 저장 완료")

cv2.destroyAllWindows()
