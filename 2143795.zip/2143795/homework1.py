import cv2 as cv
import numpy as np
import sys
img = cv.imread('soccer.jpg')

if img is None :
    sys.exit('파일이 존재하지 않습니다.')

gray = cv.cvtColor(img,cv.COLOR_BGR2GRAY) # BGR 컬러 영상을 명암 영상으로 변환
gray_small=cv.resize(gray,dsize=(0,0),fx=0.5,fy=0.5) # 반으로 축소
img = cv.resize(img,dsize=(0,0),fx=0.5,fy=0.5)
gray_small=cv.cvtColor(gray_small, cv.COLOR_GRAY2BGR)

stacked = np.hstack((img, gray_small))
cv.imshow('Color image',stacked)


cv.waitKey()
cv.destroyAllWindows()

while(True):
    key=cv.waitKey(1)
    if key:
        break






cv.imshow('Image Display', img)


cap=cv.VideoCapture(0,cv.CAP_DSHOW) # 카메라와 연결 시도

if not cap.isOpened():
    sys.exit('카메라 연결 실패')

while True:
    ret, frame=cap.read()

    if not ret:
        print('프레임 획득에 실패하여 루프를 나갑니다.')
        break

# 비디오를 구성하는 프레임 획득

    key=cv.waitKey(1)
    if key == ord('q'):
        break

cap.release()
cv.destroyAllWindows ()

cv.imshow('Video display',frame)

# 1밀리초 동안 키보드 입력 기다림
# 'q' 키가 들어오면 루프를 빠져나감

# 카메라와 연결을 끊음
cap=cv.VideoCapture(0,cv.CAP_DSHOW) # 카메라와 연결 시도

if not cap.isOpened():
    sys.exit('카메라 연결 실패')

# 페인팅 설정
BrushSize = 5
LColor, RColor = (255, 0, 0), (0, 0 ,255)
def painting(event, x, y, flags, param):
    if event == cv.EVENT_LBUTTONDOWN:
        cv.circle(img, (x, y), BrushSize, LColor, -1)
    elif event == cv.EVENT_RBUTTONDOWN:
        cv.circle(img, (x, y), BrushSize, RColor, -1)
    elif event == cv. EVENT_MOUSEMOVE and flags == cv. EVENT_FLAG_LBUTTON:
        cv.circle(img, (x, y), BrushSize, LColor, -1)
    elif event == cv. EVENT_MOUSEMOVE and flags == cv.EVENT_FLAG_RBUTTON:
        cv.circle(img, (x, y), BrushSize, RColor, -1)

cv.imshow('Painting', img)

img = cv.imread("paint.jpg")

if img is None:
    sys.exit("File not exists.")

cv.namedWindow('Painting')
cv.imshow('Painting', img)
cv.setMouseCallback('Painting', painting)

while(True):
    if cv.waitKey(1) == ord('q'):
        cv.destroyAllWindows()
        break